﻿using UnityEngine;
using System.Collections;
/******************************************************************************
 * Author: Judson James
 * Date: 10-17-16
 * Purpose: Mostly to make the movements look natural
**/
public class JudsonsCollisionCode : MonoBehaviour {

	// void Start() : Use this for initialization
	void Start () {
        	
	}
	
	// void Update() : Update is called once per frame
	void Update () {
       // if (GameObject.FindWithTag("Barrier").
       //     .IsTouching(GameObject.FindGameObjectsWithTag("Barrier")));
	}
}
